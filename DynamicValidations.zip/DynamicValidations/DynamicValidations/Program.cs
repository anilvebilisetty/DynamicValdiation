﻿using System;
using System.Collections.Generic;

namespace DynamicValidations
{
    class Program
    {
        static void Main(string[] args)
        {
            SampleClass sampleClass = new SampleClass();
            List<ResponseModel> responses = new List<ResponseModel>();
            sampleClass.Name  = "Ani";
            sampleClass.DOB = "adasasd";
            List<ValidationRules> rules = new List<ValidationRules>() {
            new ValidationRules(){ IsRequired = true, ValueType = "string",PropertyName = "Name",MinLength = 5, MaxLength = 10},new ValidationRules(){ IsRequired = true, ValueType = "date",PropertyName = "DOB"}
            };
            rules.ForEach((rule) =>
            {
                ResponseModel response = Validate.TryGetValue(rule, sampleClass, out object finalValue);
                responses.Add(response);
            });
          
        }
    }
}
