﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DynamicValidations
{
    public class ResponseModel
    {
        public string Message { get; set; }
        public string ErrorCode { get; set; }
        public bool  IsValid { get; set; }
        public string PropertyName { get; set; }

    }
}
