﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DynamicValidations
{
    public class ValidationRules
    {
        public string PropertyName { get; set; }
        public string  ValueType { get; set; }
        public bool  IsRequired { get; set; }
        public int MaxLength { get; set; }
        public int  MinLength { get; set; }
        public int MinVal { get; set; }
        public int MaxVal { get; set; }
        public int Scale { get; set; }
        public string ValuePattern { get; set; }
        public object[] ValueEnum { get; set; }

    }
}
