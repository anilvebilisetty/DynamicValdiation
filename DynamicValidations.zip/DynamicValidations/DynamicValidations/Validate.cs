﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace DynamicValidations
{
    public static class Validate
    {
        public static object GetPropValue(object src, string propName)
        {
            return src.GetType().GetProperty(propName).GetValue(src, null);
        }
        public static ResponseModel TryGetValue(ValidationRules rule, object value, out object finalValue)
        {
            ResponseModel response = new ResponseModel();
            //rule.PropertyName = "DOB";
            //rule.IsRequired = true;
            //rule.ValueType = "date";
            value  = GetPropValue(value, rule.PropertyName);
            switch (rule.ValueType)
            {
                case "string":
                    value = Convert.ToString(value);
                    if (value is string)
                    {
                        if (rule.IsRequired && string.IsNullOrWhiteSpace((string)value))
                        {
                            response.Message = $"{ rule.PropertyName } Is Required ";
                            
                            finalValue = null;
                            response.IsValid = false; return response;
                        }

                        if (!string.IsNullOrWhiteSpace(rule.ValuePattern))
                        {
                            try
                            {
                                Match match = Regex.Match((string)value, rule.ValuePattern, RegexOptions.IgnoreCase);
                                if (match.Success)
                                {
                                    value = match.Value;
                                }
                                else
                                {
                                    response.Message = $"{ rule.PropertyName } No Match For Defination Pattern ";
                                    finalValue = null;
                                    response.IsValid = false; return response;
                                }
                            }
                            catch (Exception)
                            {
                                response.Message = $"{ rule.PropertyName } Defination Pattern Is Invalid ";
                                finalValue = null;
                                response.IsValid = false; return response;
                            }
                        }

                        if (rule.ValueEnum != null && rule.ValueEnum.Length > 0 && !rule.ValueEnum.Contains(value))
                        {
                            response.Message = $"{ rule.PropertyName } Value Does Not Match Any Enum ";
                            finalValue = null;
                            response.IsValid = false; return response;
                        }

                        if (rule.MaxLength > 0 && ((string)value).Length > rule.MaxLength)
                        {
                            response.Message = $"{ rule.PropertyName } Length Exceeds Max Limit of { rule.MaxLength } ";
                            finalValue = null;
                            response.IsValid = false; return response;
                        }
                        if (rule.MinLength > 0 && ((string)value).Length < rule.MinLength)
                        {
                            response.Message = $"{ rule.PropertyName } Length is less than Min Limit of { rule.MaxLength } ";
                            finalValue = null;
                            response.IsValid = false; return response;
                        }
                        response.Message = null;
                        finalValue = value;
                        response.IsValid = true; return response;
                    }
                    else
                    {
                        response.Message = $"{ rule.PropertyName } Has Incorrect Value Type ";
                        finalValue = null;
                        response.IsValid = false; return response;
                    }
                case "smallint":
                    if (value is short)
                    {
                        response.Message = null;
                        finalValue = value;
                        response.IsValid = true; return response;
                    }
                    else
                    {
                        if (short.TryParse(value?.ToString(), out short result4))
                        {
                            response.Message = null;
                            finalValue = result4;
                            response.IsValid = true; return response;
                        }
                        else
                        {
                            response.Message = $"{ rule.PropertyName } Has Incorrect Value ";
                            finalValue = null;
                            response.IsValid = false; return response;
                        }
                    }
                case "int":
                    if (value is int)
                    {
                        response.Message = null;
                        finalValue = value;
                        response.IsValid = true; return response;
                    }
                    else
                    {
                         if (int.TryParse(value?.ToString(), out int result3))
                        {
                            response.Message = null;
                            finalValue = result3;
                            response.IsValid = true; return response;

                        }
                        else
                        {
                            response.Message = $"{ rule.PropertyName } Has Incorrect Value ";
                            finalValue = null;
                            response.IsValid = false; return response;
                        }
                    }
                case "bigint":
                    if (value is long)
                    {
                        response.Message = null;
                        finalValue = value;
                        response.IsValid = true; return response;
                    }
                    else
                    {
                        if (long.TryParse(value?.ToString(), out long result2))
                        {
                            response.Message = null;
                            finalValue = result2;
                            response.IsValid = true; return response;
                        }
                        else
                        {
                            response.Message = $"{ rule.PropertyName } Has Incorrect Value ";
                            finalValue = null;
                            response.IsValid = false; return response;
                        }
                    }
                case "decimal":
                    int scale = rule.Scale > 0 ? rule.Scale : 2;
                    if (value is decimal)
                    {
                        response.Message = null;
                        finalValue = Math.Round((decimal)value, scale);
                        response.IsValid = true; return response;
                    }
                    else
                    {
                        if (decimal.TryParse(value?.ToString(), out decimal result1))
                        {
                            response.Message = null;
                            finalValue = Math.Round(result1, scale);
                            response.IsValid = true; return response;
                        }
                        else
                        {
                            response.Message = $"{ rule.PropertyName } Has Incorrect Value ";
                            finalValue = null;
                            response.IsValid = false; return response;
                        }
                    }
                case "date":
                     if (DateTime.TryParse(value?.ToString(), out DateTime result))
                    {
                        response.Message = null;
                        finalValue = result;
                        response.IsValid = true; return response;
                    }
                    else
                    {
                        response.Message = $"{ rule.PropertyName } Has Incorrect Value. ";
                        finalValue = null;
                        response.IsValid = false; return response;
                    }

                case "bit":
                    if (value is bool)
                    {
                        response.Message = null;
                        finalValue = value;
                        response.IsValid = true; return response;
                    }
                    else
                    {
                        try
                        {
                            response.Message = null;
                            finalValue = bool.Parse(value?.ToString());
                            response.IsValid = true; return response;
                        }
                        catch (Exception)
                        {
                            response.Message = $"{ rule.PropertyName } Has Incorrect Value ";
                            finalValue = null;
                            response.IsValid = false; return response;
                        }
                    }
                default:
                    response.Message = $"{ rule.PropertyName } Has Incorrect Value ";
                    finalValue = null;
                    response.IsValid = false; return response;
            }
        }
    }

}
